rm -rf find_similar_recipes/* recipes/* get_ingredient_substitutes/* summarize_recipe/* get_product_information/*
